import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:get/get.dart';

class ConnectivityController extends GetxController {
  var isOnline = true.obs;

  @override
  void onInit() {
    super.onInit();
    _checkInitialConnectivity();
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      isOnline.value = result != ConnectivityResult.none;
    });
  }

  void _checkInitialConnectivity() async {
    var result = await Connectivity().checkConnectivity();
    isOnline.value = result != ConnectivityResult.none;
  }
}
