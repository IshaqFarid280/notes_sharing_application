import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:notes_sharing_application/const/firebase_const.dart';
import 'package:notes_sharing_application/views/auth_screen/getlocation_screen.dart';

class AuthController extends GetxController {

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//sdfsfg/sdf
  var userData = {}.obs;
  var response = '';
  var respon = '';

  var isLoading = false.obs;


  Future<void> _setInitialScreen(User? user) async {
    if (user == null) {
      Get.offAllNamed("/login");
    } else {
      bool userExists = await _checkUserExists(user.uid);
      if (userExists) {
        await _loadUserData(user.uid);
        Get.offAllNamed("/main");
      } else {
        Get.offAllNamed("/login");
        Get.snackbar("Error", "User does not exist or has been deleted", snackPosition: SnackPosition.BOTTOM);
      }
    }
  }

  Future<void> signup(String name, String email, String password, String token) async {
    try {
      isLoading(true);
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      ).then((v){

        response = v.user!.uid;
         _firestore.collection('users').doc(v.user!.uid).set({
          'name': name,
          'email': email,
          'password': password,
          'uid': response,
          'image': '',
          'location': 'location_here',
          'latitude': 'latitifude',
          'longitude': 'longitiude',
          'token': token,
          // 'token':
        });
         isLoading(false);
         return v ;
      });
      isLoading(false);
      print('THe user id in signup screen ; ${userCredential.user!.uid}');
      // Navigate to the MapScreen only after successful signup
      Get.to(() => MapScreen(userid: response));
    } catch (e) {
      isLoading(false);
      print('Signup failed: $e');
      Get.snackbar("Error", e.toString(), snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<bool> _checkUserExists(String uid) async {
    DocumentSnapshot userDoc = await _firestore.collection('users').doc(uid).get();
    return userDoc.exists;
  }

  Future<void> _loadUserData(String uid) async {
    DocumentSnapshot userDoc = await _firestore.collection('users').doc(uid).get();
    userData.value = userDoc.data() as Map<String, dynamic>;
  }

  Future<void> login(String email, String password) async {
    try {
      isLoading(true);
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(email: email, password: password);
      bool userExists = await _checkUserExists(userCredential.user!.uid);
      if (userExists) {
        await _loadUserData(userCredential.user!.uid);
        isLoading(false);
        Get.offAllNamed("/main");
      } else {
        Get.snackbar("Error", "User does not exist or has been deleted", snackPosition: SnackPosition.BOTTOM);
        isLoading(false);
        await signOut();
      }
    } catch (e) {
      isLoading(false);
      print('Login failed: $e');
      Get.snackbar("Error", e.toString(), snackPosition: SnackPosition.BOTTOM);
    }
  }

  // In auth_controller.dart
  Future<void> updateLocation(String userId, double latitude, double longitude) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(userId).update({
        'latitude': latitude,
        'longitude': longitude,
      });
    } catch (e) {
      throw Exception('Failed to update location: $e');
    }
  }

  Future<void> signOut() async {
    try {
      await _auth.signOut();
      // Clear user data
      userData.value = {};
      // Optionally, clear other state variables
      isLoading(false);
      // Navigate to the login screen
      Get.offAllNamed("/login");
    } catch (e) {
      print('Sign out failed: $e');
      Get.snackbar("Error", "Failed to sign out: ${e.toString()}", snackPosition: SnackPosition.BOTTOM);
    }
  }

}
