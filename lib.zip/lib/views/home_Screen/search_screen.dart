import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:get/get.dart';
import 'package:notes_sharing_application/const/colors.dart';
import 'package:notes_sharing_application/controlller/event_controller.dart';
import 'package:notes_sharing_application/views/home_Screen/view_subject_screen.dart';
import 'package:notes_sharing_application/widgets_common/categories_widget.dart';

class SearchScreen extends StatefulWidget {
  final String currentUserUid;

  SearchScreen({required this.currentUserUid});

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  final EventController _eventController = Get.put(EventController());
  String searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search events...',
        
                  prefixIcon: InkWell(
                      onTap: (){
                        Navigator.pop(context);
                      },
                      child: Icon(Icons.arrow_back_ios)),
                  suffixIcon: IconButton(
                    icon: Icon(Icons.clear),
                    onPressed: () {
                      _searchController.clear();
                      setState(() {
                        searchQuery = '';
                      });
                    },
                  ),
        
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4),
                    borderSide: BorderSide(color: redColor),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4),
                    borderSide: BorderSide(color: darkFontGrey),
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    searchQuery = value;
                  });
                },
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('events').snapshots(),
                builder: (BuildContext context, AsyncSnapshot<QuerySnapshot<Object?>> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text('No events found.'));
                  }
        
                  final filteredDocs = snapshot.data!.docs.where((document) {
                    final data = document.data() as Map<String, dynamic>;
                    final title = data['title']?.toString().toLowerCase() ?? '';
                    final description = data['description']?.toString().toLowerCase() ?? '';
                    return title.contains(searchQuery.toLowerCase()) || description.contains(searchQuery.toLowerCase());
                  }).toList();
        
                  if (searchQuery.isEmpty) {
                    return Container();
                  }
        
                  return ListView(
                    children: filteredDocs.map((document) {
                      final data = document.data() as Map<String, dynamic>;
                      final dateTime = (data['dateTime'] as Timestamp).toDate();
                      final formattedDateTime = DateFormat('yyyy-MM-dd – kk:mm').format(dateTime);
                      final bool isInterested = (data['isfavorite'] as List).contains(widget.currentUserUid);
                      final bool isGoing = (data['goingusers'] as List).contains(widget.currentUserUid);
                      final int invitedUserLength = (data['isfavorite'] as List).length;
                      final int isGoingLength = (data['goingusers'] as List).length;
                      //
                      // final int invitedUserLength = (data['isfavorite'] as List).length;
                      // final int isGoingLength = (data['goingusers'] as List).length;
                      //
                      //
                      return Center(
                        child: categorywidget(
                              () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ViewSubjectScreen(
                                  title: data['title'] ?? 'No Title',

                                  interested: invitedUserLength.toString() ?? 'N/A',
                                  going: isGoingLength.toString() ?? 'N/A',
                                  description: data['description'] ?? 'No Description',
                                  dateTime: formattedDateTime,
                                  imageUrl: data['images'] ?? '',
                                  location: data['locationevent'] ?? 'No Location',
                                  organizer: data['organizer'] ?? 'Unknown',
                                  currentUserUid: widget.currentUserUid,
                                  eventid: data['createdBy'] ??
                                      'No Description',
                                  lat: data['latitude'],
                                  long: data['longitude'],
                                  data: data,
                                ),
                              ),
                            );
                          },
                          Icons.add,
                          data['title'] ?? 'No Title',
                          invitedUserLength.toString(),
                          isGoingLength.toString(),
                          data['description'] ?? 'No Description',
                          formattedDateTime,
                          Colors.black,
                          Colors.white,
                          data['images'][0] ?? '',
                          context,
                          data['locationevent'] ?? 'N/A',
                              () {
                            _eventController.toggleInterest(document.id, widget.currentUserUid);
                          },
                              () {
                            _eventController.toggleGoing(document.id, widget.currentUserUid);
                          },
                          isInterested ? Icons.favorite : Icons.favorite_border,
                          isGoing ? 'You are Going' : 'Going',
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
