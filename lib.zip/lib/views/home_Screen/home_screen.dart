import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'package:notes_sharing_application/const/colors.dart';
import 'package:notes_sharing_application/const/strings.dart';
import 'package:notes_sharing_application/controlller/connectivity_controller.dart';
import 'package:notes_sharing_application/controlller/event_controller.dart';
import 'package:notes_sharing_application/views/home_Screen/add_new_subject_screen.dart';
import 'package:notes_sharing_application/views/home_Screen/calender_Screen.dart';
import 'package:notes_sharing_application/views/home_Screen/events_map_screen.dart';
import 'package:notes_sharing_application/views/home_Screen/view_subject_screen.dart';
import 'package:notes_sharing_application/views/home_Screen/search_screen.dart';
import 'package:notes_sharing_application/widgets_common/bg_widgets.dart';
import 'package:notes_sharing_application/widgets_common/categories_widget.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:notes_sharing_application/widgets_common/our_button.dart';

class HomeScreen extends StatelessWidget {
  final String currentUserUid;
  final EventController _eventController = Get.put(EventController());

  HomeScreen({required this.currentUserUid});

  Future<void> _refreshData() async {
    await _eventController.fetchEvents();
  }

  @override
  Widget build(BuildContext context) {
    final connectivityController = Get.find<ConnectivityController>();

    return bgWidget(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: redColor,
          title: normalText(text: appname, size: 18.0),

          actions: [
            InkWell(
              onTap: () {
                if (connectivityController.isOnline.value) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          AddNewSubjectScreen(currentUserUid: currentUserUid),
                    ),
                  );
                } else {
                  Get.snackbar("Error", "No Internet", snackPosition: SnackPosition.BOTTOM);
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Icon(Icons.add, color: whiteColor,),
              ),
            ),
            InkWell(
              onTap: () {
                if (connectivityController.isOnline.value) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => EventsMapScreen(
                        currentUserUid: currentUserUid,
                      ),
                    ),
                  );
                } else {
                  Get.snackbar("Error", "No Internet", snackPosition: SnackPosition.BOTTOM);
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Icon(Icons.map, color: whiteColor,),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 4.0, right: 8.0, top: 4.0, bottom: 4.0),
              child: InkWell(
                onTap: () {
                  if (connectivityController.isOnline.value) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SearchScreen(currentUserUid: currentUserUid, ),
                      ),
                    );
                  } else {
                    Get.snackbar("Error", "Something went wrong. Check your internet Connection", snackPosition: SnackPosition.BOTTOM);
                  }
                },
                child: Icon(Icons.search, color: whiteColor,),
              ),
            ),
          ],
        ),
        body: Obx(() {
          if (connectivityController.isOnline.value) {
            return RefreshIndicator(
              onRefresh: _refreshData,
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('events').snapshots(),
                builder: (BuildContext context, AsyncSnapshot<QuerySnapshot<Object?>> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: SpinKitPouringHourGlassRefined(
                        color: darkFontGrey.withOpacity(0.5),
                        size: 50.0,
                        strokeWidth: 1.5,
                        duration: Duration(milliseconds: 1000),

                      ),
                    );
                  }
                  if (snapshot.hasError) {
                    return Image.asset(
                      'assets/slowconnections.jpeg',
                      width: MediaQuery.of(context).size.width * 1,
                      height: MediaQuery.of(context).size.height * 0.5,
                      fit: BoxFit.contain,
                    );
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(
                      child: Image.asset(
                        'assets/myeventEMPTY.jpeg',
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.5,
                        fit: BoxFit.contain,
                      ),
                    );
                  }

                  return SingleChildScrollView(
                    child: AnimationLimiter(
                      child: Column(
                        children: AnimationConfiguration.toStaggeredList(
                          duration: const Duration(milliseconds: 375),
                          childAnimationBuilder: (widget) => SlideAnimation(
                            horizontalOffset: MediaQuery.of(context).size.width / 2,
                            child: FadeInAnimation(child: widget),
                          ),
                          children: snapshot.data!.docs.map((document) {
                            final data = document.data() as Map<String, dynamic>;
                            final String documentId = document.id; // Get the document ID
                            final dateTime = (data['dateTime'] as Timestamp).toDate();

                            final formattedDateTime = DateFormat('yyyy-MM-dd – kk:mm').format(dateTime);
                            final bool isInterested = (data['isfavorite'] as List).contains(currentUserUid);
                            final bool isGoing = (data['goingusers'] as List).contains(currentUserUid);

                            final int invitedUserLength = (data['isfavorite'] as List).length;
                            final int isGoingLength = (data['goingusers'] as List).length;

                            return Center(
                              child: categorywidget(
                                    () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => ViewSubjectScreen(
                                        title: data['title'] ?? 'No Title',
                                        interested: invitedUserLength.toString() ?? 'N/A',
                                        going: isGoingLength.toString() ?? 'N/A',
                                        description: data['description'] ?? 'No Description',
                                        dateTime: formattedDateTime,
                                        imageUrl: data['images'] ?? '',
                                        location: data['locationevent'] ?? 'No Location',
                                        organizer: data['createdBy'] ?? 'Unknown',
                                        currentUserUid: currentUserUid,
                                        eventid: data['createdBy'] ?? 'No Description',
                                        lat: data['latitude'],
                                        long: data['longitude'],
                                        data: data,

                                      ),
                                    ),
                                  );
                                },
                                Icons.add,
                                data['title'] ?? 'No Title',
                                invitedUserLength.toString() ?? 'N/A',
                                isGoingLength.toString() ?? 'N/A',
                                data['description'] ?? 'No Description',
                                formattedDateTime,
                                Colors.black,
                                Colors.white,
                                data['images'][0] ?? '',
                                context,
                                data['locationevent'] ?? 'N/A',
                                    () {
                                  _eventController.toggleInterest(document.id, currentUserUid);
                                },
                                    () {
                                  _eventController.toggleGoing(document.id, currentUserUid);
                                },
                                isInterested ? Icons.favorite : Icons.favorite_border,
                                isGoing ? 'You are Going' : 'Going',
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  );
                },
              ),
            );
          } else {
            return Center(
              child: Image.asset('assets/slowconnections.jpeg'),
            );
          }
        }),
      ),
    );
  }
}
