
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:latlong2/latlong.dart';
import 'package:notes_sharing_application/const/colors.dart';
import 'package:notes_sharing_application/controlller/event_controller.dart';
import 'package:notes_sharing_application/widgets_common/categories_widget.dart';
import 'package:notes_sharing_application/widgets_common/our_button.dart';
import 'package:notes_sharing_application/widgets_common/small_categories_widget.dart';

class ViewSubjectScreen extends StatefulWidget {
  final String title;
  final dynamic data;
  final String interested;
  final String going;
  final String description;
  final String dateTime;
  final List<dynamic> imageUrl;
  final String location;
  final String organizer;

  final String currentUserUid;
  final String eventid;
  final double lat;
  final double  long;


   ViewSubjectScreen({
    super.key,
    required this.title,
    required this.interested,
    required this.going,
    required this.description,
    required this.dateTime,
    required this.imageUrl,
    required this.location,
    required this.organizer,
    required this.currentUserUid,
    required this.eventid,
    required this.lat,
    required this.long,
     required this.data,
  });

  @override
  State<ViewSubjectScreen> createState() => _ViewSubjectScreenState();
}

class _ViewSubjectScreenState extends State<ViewSubjectScreen> {
  final EventController _eventController = Get.put(EventController());

  final List<Marker> _markers = [];

  final MapController _mapController = MapController();

  Map<String, dynamic>? _selectedEventData;

  LatLng? _infoWindowPosition;

  TextEditingController _searchController = TextEditingController();

  String _searchQuery = '';

  List<Map<String, dynamic>> _searchResults = [];
  @override
  void initState() {
    super.initState();
    _loadEventMarkers();
  }
  Future<void> _loadEventMarkers() async {
    // final snapshot = await FirebaseFirestore.instance.collection('events').get();
    _markers.clear(); // Clear existing markers before adding new ones
    _searchResults.clear(); // Clear existing search results before adding new ones

    // for (var document in snapshot.docs) {
    //   final data = document.data() as Map<String, dynamic>;
    //   final address = data['locationevent'];
    //
    //   if ((data['title'] ?? '').toString().toLowerCase().contains(_searchQuery.toLowerCase()) ||
    //       (data['description'] ?? '').toString().toLowerCase().contains(_searchQuery.toLowerCase())) {
    //
    //   }
    // }

      List<Placemark> placemarks  = await placemarkFromCoordinates(widget.lat, widget.long);
      if (placemarks.isNotEmpty) {
        Placemark place = placemarks.first;
        String address = "${place.street}, ${place.locality}, ${place.country}";

        setState(() {
          _markers.add(
            Marker(
              point:  LatLng(widget.lat, widget.long),
              child: GestureDetector(
                onTap: () {
                  // _showEventDetails(data, LatLng(widget.lat, widget.long));
                },
                child: Icon(Icons.location_on, color: Colors.red, size: 40),
              ),
            ),
          );
          // _searchResults.add(data);
        });
      }

  }

  void _showEventDetails(Map<String, dynamic> eventData, LatLng position) {
    setState(() {
      _selectedEventData = eventData;
      _infoWindowPosition = position;
    });
  }



  @override
  Widget build(BuildContext context) {
    final bool isInterested = (widget.data['isfavorite'] as List).contains(widget.currentUserUid);
    final bool isGoing = (widget.data['goingusers'] as List).contains(widget.currentUserUid);

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [

              SizedBox(
                height: MediaQuery.of(context).size.height * 0.4, // Specify a definite height

                child: CarouselView(
                  padding: EdgeInsets.zero,
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  itemExtent: MediaQuery.of(context).size.width*0.9,
                  controller: CarouselController(), // Optional: Create a controller if needed
                  scrollDirection: Axis.horizontal,
                  reverse: false,
                  shrinkExtent: 50.0,


                  // itemSnapping: true, // Enable item snapping for smooth scrolling

                    // height: MediaQuery.of(context).size.height * 0.4,
                    // autoPlay: true,
                    // autoPlayInterval: Duration(seconds: 3),
                    // viewportFraction: 1.0,
                    // enlargeCenterPage: true,
                    // aspectRatio: 16 / 9,
                    // onPageChanged: (index, reason) {},

                  children: widget.imageUrl.map((imageUrl) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                          width: MediaQuery.of(context).size.width,

                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8
                            ),
                            child: Image.network(
                              imageUrl,
                              fit: BoxFit.cover,
                            ),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
              ),
              normalText(
                text: widget.dateTime,
                size: 11.0,
                color: Colors.grey.withOpacity(0.8),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40.0),
                child: normalText(
                  text: widget.title,
                  size: 19.0,
                  color: darkFontGrey,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  normalText(
                    text: 'Public',
                    size: 11.0,
                    color: Colors.grey.withOpacity(0.8),
                  ),
                  normalText(
                    text: ' - Event by ',
                    size: 11.0,
                    color: Colors.grey.withOpacity(0.8),
                  ),
                  FutureBuilder<DocumentSnapshot>(
                    future: FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.organizer)
                        .get(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Text(
                          'Loading...',
                          style: TextStyle(
                            fontSize: 11.0,
                            color: darkFontGrey,
                          ),
                        );
                      }

                      if (snapshot.hasError) {
                        return Text(
                          'Error',
                          style: TextStyle(
                            fontSize: 11.0,
                            color: darkFontGrey,
                          ),
                        );
                      }

                      if (!snapshot.hasData || !snapshot.data!.exists) {
                        return Text(
                          'Organizer not found',
                          style: TextStyle(
                            fontSize: 11.0,
                            color: darkFontGrey,
                          ),
                        );
                      }

                      final organizerProfile = snapshot.data!.data() as Map<String, dynamic>;
                      return GestureDetector(
                        onTap: () {
                          // Show dialog when tapped
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20)
                                ),
                                title: Text('Organizer Details'),
                                content: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Center(
                                      child: CircleAvatar(
                                        radius: 50,
                                        backgroundImage: organizerProfile['image'] != null
                                            ? NetworkImage(organizerProfile['image'],)
                                            : AssetImage('assets/placeholder.png') as ImageProvider,
                                      ),
                                    ),
                                    SizedBox(height: 20),
                                    Text('Name: ${organizerProfile['name'] ?? 'No Name'}',),
                                    SizedBox(height: 10),
                                    Text('Email: ${organizerProfile['email'] ?? 'No Email'}'),
                                    // SizedBox(height: 5),
                                    // Text('Phone: ${organizerProfile['phone'] ?? 'No Phone'}'),
                                  ],
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop(); // Close the dialog
                                    },
                                    style: TextButton.styleFrom(
                                      foregroundColor: whiteColor,
                                      backgroundColor: redColor,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(20), // Rounded corners
                                      ),
                                      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20), // Padding
                                    ),
                                    child: Text('Close'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        child: Text(
                          organizerProfile['name'] ?? 'No Name',
                          style: TextStyle(
                            fontSize: 11.0,
                            color: darkFontGrey,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      );

                    },
                  ),

                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Obx(
                    () {
                      return customButton(
                        widths: 0.4,
                        favoritebuttonontap: () {},
                        intrestedbuttonontap: () {

                            _eventController.toggleInterest(
                                widget.eventid, widget.currentUserUid);

                        },
                        text: 'Interested',
                        buttonColors: _eventController.isInterest.value ?  redColor : Colors.grey.withOpacity(0.2),
                        isfavorite: false,
                        textcolor: _eventController.isInterest.value ?  whiteColor : Colors.black,
                        isicon: true,
                        icons:  _eventController.isInterest.value ?  Icons.star_border : Icons.star,
                        iconColor: _eventController.isInterest.value ?  whiteColor : Colors.black,
                      );
                    }
                  ),
                  Obx(
                     () {
                      return customButton(
                        widths: 0.4,
                        buttonColors: _eventController.isGoing.value  ?  redColor : Colors.grey.withOpacity(0.2),
                        favoritebuttonontap: () {},
                        intrestedbuttonontap: () {

                          _eventController.toggleGoing(
                              widget.eventid,  widget.currentUserUid);
                        },
                        text: 'Going',
                        isfavorite: false,
                        textcolor: _eventController.isGoing.value ?whiteColor  :   Colors.black,
                        isicon: false,
                        icons: _eventController.isGoing.value ?   Icons.mail_lock_outlined : Icons.outgoing_mail,
                        iconColor: _eventController.isGoing.value ?  whiteColor :   Colors.black,
                      );
                    }
                  ),
                ],
              ),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Icon(Icons.location_pin),

                    Expanded(
                      child: Text(
                           widget.location,
                          style: TextStyle(
                              color: darkFontGrey.withOpacity(0.9),
                              fontWeight: FontWeight.w400
                          ),

                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0, right: 8.0, bottom: 8.0),
                child: Row(
                  children: [
                    Icon(Icons.check_box),
                    Padding(
                      padding: const EdgeInsets.only(left: 6.0),
                      child: normalText(
                          text: '${widget.going} going',
                          color: darkFontGrey.withOpacity(0.9),
                        weight: FontWeight.w400
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0, right: 8.0, bottom: 8.0),
                child: Row(
                  children: [
                    Icon(Icons.star),
                    Padding(
                      padding: const EdgeInsets.only(left: 6.0),
                      child: normalText(
                          text: '${widget.interested} interested',
                          color: darkFontGrey.withOpacity(0.9),
                        weight: FontWeight.w400
                      ),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Divider(
                  thickness: 2.0,
                  color: darkFontGrey.withOpacity(0.1),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        normalTextwithoutcenter(
                          text: 'What to expect',
                          size: 18.0,
                          color: darkFontGrey
                        ),
                      ],
                    ),
                    normalTextwithoutcenter(
                      text: widget.description,
                      size: 12.0,
                      color: darkFontGrey.withOpacity(0.7),
                      weight: FontWeight.w400
                    ),
                  ],
                ),
              ),

              SizedBox(
                height: 10,
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Row(
                  children: [
                    normalTextwithoutcenter(
                        text: 'Location',
                        size: 18.0,
                        color: darkFontGrey
                    ),
                  ],
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  height: MediaQuery.of(context).size.height*0.15,
                  width: MediaQuery.of(context).size.width*0.9,
                 
                  child: FlutterMap(
                
                    mapController: _mapController,
                    options: MapOptions(
                      initialCenter: LatLng(widget.lat, widget.long),
                      initialZoom: 14.0,
                    ),
                    children: [
                      TileLayer(
                        urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                        subdomains: ['a', 'b', 'c'],
                      ),
                      MarkerLayer(
                        markers: _markers,
                      ),
                    ],
                  ),
                ),
              ),



              SizedBox(
                height: 20,
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Row(
                  children: [
                    normalTextwithoutcenter(
                        text: 'More Events Happening',
                        size: 18.0,
                        color: darkFontGrey
                    ),
                  ],
                ),
              ),
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('events').snapshots(),
                builder: (BuildContext context, AsyncSnapshot<QuerySnapshot<Object?>> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: SpinKitPouringHourGlassRefined(
                      color: darkFontGrey.withOpacity(0.5),
                      size: 50.0,
                      strokeWidth: 1.5,
                      duration: Duration(milliseconds: 1000),

                    ),);
                  }
                  if (snapshot.hasError) {

                    return  Image.asset(
                      'assets/slowconnections.jpeg',
                      width: MediaQuery.of(context).size.width * 1,
                      height: MediaQuery.of(context).size.height * 0.5,
                      fit: BoxFit.contain,
                    );

                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(
                      child: Image.asset(
                        'assets/myeventEMPTY.jpeg',
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.5,
                        fit: BoxFit.contain,
                      ),
                    );
                  }

                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: snapshot.data!.docs.map((document) {
                        final data = document.data() as Map<String, dynamic>;
                        final dateTime = (data['dateTime'] as Timestamp).toDate();
                        final formattedDateTime = DateFormat('yyyy-MM-dd – kk:mm').format(dateTime);
                        final bool isInterested = (data['isfavorite'] as List).contains(widget.currentUserUid);
                        final bool isGoing = (data['goingusers'] as List).contains(widget.currentUserUid);


                        final int inviteduserlength =  (data['isfavorite'] as List).length;
                        final int iisGoinglength =  (data['goingusers'] as List).length;

                        return Center(
                          child: Container(
                            width: MediaQuery.of(context).size.width*0.7,
                            height: MediaQuery.of(context).size.height*0.4,
                            child: categorywidgetSMALL(
                                  () {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ViewSubjectScreen(
                                      title: data['title'] ?? 'No Title',
                                      interested: inviteduserlength.toString() ?? 'N/A',
                                      going: iisGoinglength.toString() ?? 'N/A',
                                      description: data['description'] ?? 'No Description',
                                      dateTime: formattedDateTime,
                                      imageUrl: data['images'] ?? '',
                                      location: data['locationevent'] ?? 'No Location',
                                      organizer: data['organizer'] ?? 'Unknown',
                                      currentUserUid: widget.currentUserUid,
                                      eventid: data['createdBy'] ??
                                        'No Description',
                                      lat: data['latitude'],
                                      long: data['longitude'],
                                      data: data,
                                    ),
                                  ),
                                );
                              },
                              Icons.add,
                              data['title'] ?? 'No Title',
                              inviteduserlength.toString() ?? 'N/A',
                              iisGoinglength.toString() ?? 'N/A',
                              data['description'] ?? 'No Description',
                              formattedDateTime,
                              Colors.black,
                              Colors.white,
                              data['images'][0] ?? '',
                              context,
                              data['locationevent'] ?? 'N/A',
                                  () {
                                _eventController.toggleInterest(document.id, widget.currentUserUid);
                                // favorite button - smaall button to favorite

                              },
                                  () {
                                _eventController.toggleGoing(document.id, widget.currentUserUid);
                                // interested buton - the big button
                              },
                              isInterested ? Icons.favorite : Icons.favorite_border,
                              isGoing ? 'You are Going' : 'Going',

                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
