import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

enum CalendarViews {
  day,
  week,
  month,
  year,
}

class CalendarScreen extends StatefulWidget {
  final String currentUserUid;

  CalendarScreen({required this.currentUserUid});

  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _selectedDate = DateTime.now();
  late Stream<QuerySnapshot> _eventsStream;
  CalendarView _currentView = CalendarView.month;
  List<Appointment> _appointments = [];

  @override
  void initState() {
    super.initState();
    _eventsStream = _getEventsForDate(_selectedDate);
  }

  Stream<QuerySnapshot> _getEventsForDate(DateTime date) {
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = DateTime(date.year, date.month, date.day, 23, 59, 59);

    print('Fetching events from ${startOfDay.toIso8601String()} to ${endOfDay.toIso8601String()}');

    return FirebaseFirestore.instance
        .collection('events')
        .where('dateTime', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('dateTime', isLessThanOrEqualTo: Timestamp.fromDate(endOfDay))
        .snapshots();
  }

  void _onDateSelected(DateTime date) {
    setState(() {
      _selectedDate = date;
      _eventsStream = _getEventsForDate(date);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event Calendar'),
        actions: [
          PopupMenuButton<CalendarView>(
            onSelected: (view) {
              setState(() {
                _currentView = view;
              });
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: CalendarView.day,
                child: Text('Day View'),
              ),
              PopupMenuItem(
                value: CalendarView.week,
                child: Text('Week View'),
              ),
              PopupMenuItem(
                value: CalendarView.month,
                child: Text('Month View'),
              ),
            ],
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _eventsStream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (!snapshot.hasData) {
            return Center(child: Text('No events found.'));
          } else {
            _appointments = snapshot.data!.docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;
              DateTime dateTime = (data['dateTime'] as Timestamp).toDate();
              print('Event fetched: ${data['title']} at ${dateTime.toIso8601String()}'); // Debugging line
              return Appointment(
                startTime: dateTime,
                endTime: dateTime.add(Duration(hours: 2)), // Example duration
                subject: data['title'] ?? 'No Title',
                notes: data['description'] ?? 'No Description',
              );
            }).toList();

            return SfCalendar(
              view: _currentView,
              dataSource: AppointmentDataSource(_appointments),
              appointmentBuilder: (BuildContext context,
                  CalendarAppointmentDetails details) {
                final Appointment appointment = details.appointments.first;
                return Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        appointment.subject,
                        style: TextStyle(color: Colors.black,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        appointment.notes!,
                        style: TextStyle(color: Colors.black),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                      ),
                    ],
                  ),
                );
              },
              onTap: (details) {
                if (details.appointments!.isNotEmpty) {
                  final event = details.appointments!.first;
                  _showEventDetails(event);
                }
              },
            );
          }
        },
      ),
    );
  }

  void _showEventDetails(Appointment event) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(event.subject),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Description: ${event.notes}'),
            Text('Start Time: ${DateFormat('yyyy-MM-dd – kk:mm').format(event.startTime)}'),
            Text('End Time: ${DateFormat('yyyy-MM-dd – kk:mm').format(event.endTime)}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }
}

class AppointmentDataSource extends CalendarDataSource {
  AppointmentDataSource(List<Appointment> appointments) {
    this.appointments = appointments;
  }
}
