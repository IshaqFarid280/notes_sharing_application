import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:get/get.dart';
import 'package:latlong2/latlong.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geocoding/geocoding.dart';
import 'package:intl/intl.dart';
import 'package:notes_sharing_application/const/colors.dart';
import 'package:notes_sharing_application/controlller/connectivity_controller.dart';
import 'package:notes_sharing_application/controlller/event_controller.dart';
import 'package:notes_sharing_application/widgets_common/our_button.dart';

class EventsMapScreen extends StatefulWidget {
  final String currentUserUid;

  EventsMapScreen({required this.currentUserUid});

  @override
  _EventsMapScreenState createState() => _EventsMapScreenState();
}

class _EventsMapScreenState extends State<EventsMapScreen> {
  final List<Marker> _markers = [];
  final MapController _mapController = MapController();
  Map<String, dynamic>? _selectedEventData;
  LatLng? _infoWindowPosition;
  TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  List<Map<String, dynamic>> _searchResults = [];
  final EventController _eventController = Get.put(EventController());

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
    _loadEventMarkers();
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text;
      _loadEventMarkers();
    });
  }

  Future<void> _loadEventMarkers() async {
    final snapshot = await FirebaseFirestore.instance.collection('events').get();
    _markers.clear(); // Clear existing markers before adding new ones
    _searchResults.clear(); // Clear existing search results before adding new ones

    for (var document in snapshot.docs) {
      final data = document.data() as Map<String, dynamic>;
      final address = data['locationevent'];

      if ((data['title'] ?? '').toString().toLowerCase().contains(_searchQuery.toLowerCase()) ||
          (data['description'] ?? '').toString().toLowerCase().contains(_searchQuery.toLowerCase())) {
        if (address != null) {
          List<Location> locations = await locationFromAddress(address);
          if (locations.isNotEmpty) {
            final location = locations.first;
            setState(() {
              _markers.add(
                Marker(
                  point: LatLng(location.latitude, location.longitude),
                  child: GestureDetector(
                    onTap: () {
                      _showEventDetails(data, LatLng(location.latitude, location.longitude));
                    },
                    child: Icon(Icons.location_on, color: Colors.red, size: 40),
                  ),
                ),
              );
              _searchResults.add(data);
            });
          }
        }
      }
    }
  }

  void _showEventDetails(Map<String, dynamic> eventData, LatLng position) {
    setState(() {
      _selectedEventData = eventData;
      _infoWindowPosition = position;
    });
  }

  @override
  Widget build(BuildContext context) {
    // final connectivityController = Get.find<ConnectivityController>();

    return Scaffold(

      body: SafeArea(
        child: Column
                  (
                  children: [
                    Padding(
         padding: const EdgeInsets.all(8.0),
         child: TextFormField(
           controller: _searchController,
           decoration: InputDecoration(
             prefixIcon: InkWell(
               onTap: (){
                 Navigator.pop(context);
               },
                 child: Icon(Icons.arrow_back_ios)),
             labelText: 'Search Events',
             suffixIcon: _searchController.text.isNotEmpty
                 ? IconButton(
               icon: Icon(Icons.clear, color: redColor,),
               onPressed: () {
                 setState(() {
                   _searchQuery = '';
                   _searchResults = [];
        
                   _searchController.clear();
                 });
                 _loadEventMarkers(); // Reload markers after clearing search
               },
             )
                 : IconButton(
               icon: Icon(Icons.search,),
               onPressed: () {
                 _loadEventMarkers(); // Reload markers on search button press
               },
             ),
             focusedBorder: OutlineInputBorder(
               borderRadius: BorderRadius.circular(4),
               borderSide: BorderSide(color: redColor),
             ),
             enabledBorder: OutlineInputBorder(
               borderRadius: BorderRadius.circular(4),
               borderSide: BorderSide(color: darkFontGrey),
             ),
             hintStyle: TextStyle(
                 fontWeight: FontWeight.normal,
                 color: Colors.black,
                 fontSize: 14.0
             ),
           ),
           onChanged: (value) {
             if(_searchController.text.isEmpty){
            _searchResults = [];
             }
             setState(() {
        
             });
           },
         ),
        
                    ),
                    if (_searchController.text.isNotEmpty)
         Expanded(
           child: ListView.builder(
             itemCount: _searchResults.length,
             itemBuilder: (context, index) {
               final eventData = _searchResults[index];
               final dateTime = eventData['dateTime'] != null
                   ? (eventData['dateTime'] as Timestamp).toDate()
                   : null;
               final formattedDateTime = dateTime != null
                   ? DateFormat('yyyy-MM-dd – kk:mm').format(dateTime)
                   : 'No Date';
        
               return ListTile(
                 leading: CircleAvatar(
                     backgroundColor: darkFontGrey.withOpacity(0.34),
                     child: Icon(Icons.location_on_sharp, color: whiteColor.withOpacity(0.9),)),
                 title: Text(eventData['title'] ?? 'No Title'),
                 trailing: InkWell(
                     onTap: (){
        
                       final address = eventData['locationevent'];
                       if (address != null) {
                         locationFromAddress(address).then((locations) {
                           if (locations.isNotEmpty) {
                             final location = locations.first;
                             _mapController.move(
                               LatLng(location.latitude, location.longitude),
                               14.0,
                             );
                             setState(() {
                               _showEventDetails(eventData, LatLng(location.latitude, location.longitude));
                               _searchResults = [];
        
                               _searchController.clear();
                               FocusScope.of(context).unfocus();
                             });
                           }
                         });
                       }
                     },
                     child: Icon(Icons.south_east)),
                 subtitle: Text(formattedDateTime),
                 onTap: () {
                   final address = eventData['locationevent'];
                   if (address != null) {
                     locationFromAddress(address).then((locations) {
                       if (locations.isNotEmpty) {
                         final location = locations.first;
                         _mapController.move(
                           LatLng(location.latitude, location.longitude),
                           14.0,
                         );
                         setState(() {
                           _showEventDetails(eventData, LatLng(location.latitude, location.longitude));
                           _searchResults = [];
        
                           _searchController.clear();
                           FocusScope.of(context).unfocus();
                         });
                       }
                     });
                   }
                 },
               );
             },
           ),
         ),
                    Expanded(
         child: Stack(
           children: [
             FlutterMap(
               mapController: _mapController,
               options: MapOptions(
                 initialCenter: LatLng(30.3753, 69.3451), // Center of Pakistan
                 initialZoom: 6.0,
               ),
               children: [
                 TileLayer(
                   urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                   subdomains: ['a', 'b', 'c'],
                 ),
                 MarkerLayer(
                   markers: _markers,
                 ),
               ],
             ),
             if (_selectedEventData != null && _infoWindowPosition != null)
               Positioned(
                 left: MediaQuery.of(context).size.width / 2 - 100,
                 top: MediaQuery.of(context).size.height / 2 - 150,
                 child: _buildInfoWindow(),
               ),
           ],
         ),
                    ),
                  ],
                ),
      ),
    );
  }

  Widget _buildInfoWindow() {
    final dateTime = _selectedEventData!['dateTime'] != null
        ? (_selectedEventData!['dateTime'] as Timestamp).toDate()
        : null;
    final formattedDateTime = dateTime != null
        ? DateFormat('yyyy-MM-dd – kk:mm').format(dateTime)
        : 'No Date';


    return Container(
      width: MediaQuery.of(context).size.width * 0.6,
      padding: EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 4.0,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
             borderRadius: BorderRadius.circular(8),
            child: Image.network(
              _selectedEventData!['images'][0],
              width: MediaQuery.of(context).size.width * 0.59,
            ),
          ),
          Text(
            _selectedEventData!['title'] ?? 'No Title',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 4.0),
          Text(
            _selectedEventData!['description'] ?? 'No Description',
            style: TextStyle(),
            maxLines: 2,
          ),
          SizedBox(height: 8.0),
          normalTextwithoutcenter(text: ' $formattedDateTime', color: Colors.black),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [


              Obx(() {
                bool isGoing = (_selectedEventData!['goingusers'] as List).contains(widget.currentUserUid);

                return GestureDetector(
                    onTap: () {
                      // final bool isGoing = (_selectedEventData!['goingusers'] as List).contains(widget.currentUserUid);
                      _eventController.toggleGoing( _selectedEventData!['eventId'], widget.currentUserUid);
                     },
                    child: Container(
                      padding: EdgeInsets.all(6),

                      decoration: BoxDecoration(
                        color: redColor,
                        borderRadius: BorderRadius.circular(4)
                      ),
                        child: normalText(text: _eventController.isGoing.value ? 'You are Going' : 'Going', color: whiteColor)),
                  );
                }
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedEventData = null;
                    _infoWindowPosition = null;
                  });
                },
                child: Icon(Icons.close, color: darkFontGrey,)
              ),
            ],
          ),
        ],
      ),
    );
  }
}
