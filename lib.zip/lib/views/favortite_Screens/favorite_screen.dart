import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:notes_sharing_application/const/colors.dart';
import 'package:notes_sharing_application/const/firebase_const.dart';
import 'package:notes_sharing_application/const/styles.dart';
import 'package:notes_sharing_application/controlller/connectivity_controller.dart';
import 'package:notes_sharing_application/controlller/event_controller.dart';
import 'package:notes_sharing_application/views/home_Screen/view_subject_screen.dart';
import 'package:notes_sharing_application/widgets_common/bg_widgets.dart';
import 'package:notes_sharing_application/widgets_common/categories_widget.dart';
import 'package:notes_sharing_application/widgets_common/our_button.dart';
import 'package:velocity_x/velocity_x.dart';

class FavoriteScreen extends StatelessWidget {
  final String currentUserUid;
  final EventController _eventController = Get.put(EventController());

  FavoriteScreen({required this.currentUserUid});

  @override
  Widget build(BuildContext context) {

    final connectivityController = Get.find<ConnectivityController>();
    return bgWidget(
      child: Scaffold(
        backgroundColor: whiteColor,
        appBar: AppBar(

          backgroundColor: redColor,
          elevation: 0,
          automaticallyImplyLeading: false,
          title: normalText(
            text: 'My Favorites',
            size: 18.0
          )
        ),
          body: Obx( () {
        if (connectivityController.isOnline.value) {
            return StreamBuilder<QuerySnapshot>(
              stream: firestore.collection('events').snapshots(),
              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot<Object?>> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child:SpinKitPouringHourGlassRefined(
                    color: darkFontGrey.withOpacity(0.5),
                    size: 50.0,
                    strokeWidth: 1.5,
                    duration: Duration(milliseconds: 1000),

                  ),


                  );
                }
                if (snapshot.hasError) {
                  return Image.asset(
                    'assets/slowconnections.jpeg',
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.5,
                    fit: BoxFit.contain,
                  );
                }
                if (!snapshot.hasData) {
                  return Image.asset(
                    'assets/myeventEMPTY.jpeg',
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.5,
                    fit: BoxFit.contain,
                  );
                }

                // Filter events based on isInterested condition
                var favoriteEvents = snapshot.data!.docs.where((document) {
                  final data = document.data() as Map<String, dynamic>;
                  return (data['isfavorite'] as List).contains(currentUserUid);
                }).toList();

                if (favoriteEvents.isEmpty) {
                  return Center(
                    child: Image.asset(
                      'assets/myeventEMPTY.jpeg',
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.5,
                      fit: BoxFit.contain,
                    ),
                  );
                }

                return SingleChildScrollView(
                    child: AnimationLimiter(
                      child: Column(

                        children: AnimationConfiguration.toStaggeredList(
                          duration: const Duration(milliseconds: 375),
                          childAnimationBuilder: (widget) => SlideAnimation(
                            horizontalOffset: MediaQuery.of(context).size.width / 2,
                            child: FadeInAnimation(child: widget),
                          ),
                      children: favoriteEvents.map((document) {
                        final data = document.data() as Map<String, dynamic>;
                        final dateTime = (data['dateTime'] as Timestamp).toDate();
                        final formattedDateTime = DateFormat('yyyy-MM-dd – kk:mm').format(dateTime);

                        final bool isInterested = (data['isfavorite'] as List).contains(currentUserUid);
                        final bool isGoing = (data['goingusers'] as List).contains(currentUserUid);

                        final int invitedUserLength = (data['isfavorite'] as List).length;
                        final int isGoingLength = (data['goingusers'] as List).length;

                        return Center(
                          child: categorywidget(
                                () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ViewSubjectScreen(
                                    title: data['title'] ?? 'No Title',
                                    interested: invitedUserLength.toString() ?? 'N/A',
                                    going: isGoingLength.toString() ?? 'N/A',
                                    description: data['description'] ?? 'No Description',
                                    dateTime: formattedDateTime,
                                    imageUrl: data['images'] ?? '',
                                    location: data['locationevent'] ?? 'No Location',
                                    organizer: data['createdBy'] ?? 'Unknown',
                                    currentUserUid: currentUserUid,
                                    eventid: data['createdBy'] ?? 'No Description',
                                    lat: data['latitude'],
                                    long: data['longitude'],
                                    data: data,

                                  ),
                                ),
                              );
                            },
                            Icons.add,
                            data['title'] ?? 'No Title',
                            invitedUserLength.toString() ?? 'N/A',
                            isGoingLength.toString() ?? 'N/A',
                            data['description'] ?? 'No Description',
                            formattedDateTime,
                            Colors.black,
                            Colors.white,
                            data['images'][0] ?? '',
                            context,
                            data['locationevent'] ?? 'N/A',
                                () {
                              _eventController.toggleInterest(document.id, currentUserUid);
                            },
                                () {
                              _eventController.toggleGoing(document.id, currentUserUid);
                            },
                            isInterested ? Icons.favorite : Icons.favorite_border,
                            isGoing ? 'You are Going' : 'Going',
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ));
              },
            );
        }
        else {
          return Center(
            child: Image.asset('assets/slowconnections.jpeg'),
          );
        }
          })
      ),
    );
  }
}
