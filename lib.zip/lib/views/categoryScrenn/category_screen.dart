import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:notes_sharing_application/const/colors.dart';
import 'package:notes_sharing_application/const/firebase_const.dart';
import 'package:notes_sharing_application/controlller/connectivity_controller.dart';
import 'package:notes_sharing_application/views/categoryScrenn/notify_all_users_Screen.dart';
import 'package:notes_sharing_application/views/home_Screen/view_subject_screen.dart';
import 'package:notes_sharing_application/widgets_common/categories_widget.dart';
import 'package:notes_sharing_application/widgets_common/our_button.dart';
import 'package:velocity_x/velocity_x.dart';
import '../../widgets_common/bg_widgets.dart';

class CategoryScreen extends StatelessWidget {
  final String currentUserUid;

  CategoryScreen({required this.currentUserUid});

  @override
  Widget build(BuildContext context) {

    final connectivityController = Get.find<ConnectivityController>();
    return bgWidget(

      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: redColor,
          automaticallyImplyLeading: false,
          title: normalText(text: 'My Events', size: 18.0),
          // actions: [
          //   Padding(
          //     padding: const EdgeInsets.only(
          //         left: 4.0, right: 8.0, top: 4.0, bottom: 4.0),
          //     child: Icon(Icons.search),
          //   ),
          // ],
        ),
          body: Obx( () {
            if (connectivityController.isOnline.value) {
              return StreamBuilder<QuerySnapshot>(
                stream: firestore.collection('events').snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot<Object?>> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: SpinKitPouringHourGlassRefined(
                      color: darkFontGrey.withOpacity(0.5),
                      size: 50.0,
                      strokeWidth: 1.5,
                      duration: Duration(milliseconds: 1000),

                    ),);
                  }
                  if (snapshot.hasError) {
                    return Image.asset(
                      'assets/slowconnections.jpeg',
                      width: MediaQuery
                          .of(context)
                          .size
                          .width * 1,
                      height: MediaQuery
                          .of(context)
                          .size
                          .height * 0.5,
                      fit: BoxFit.contain,
                    );
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(
                      child: Image.asset(
                        'assets/myeventEMPTY.jpeg',
                        width: MediaQuery
                            .of(context)
                            .size
                            .width * 1,
                        height: MediaQuery
                            .of(context)
                            .size
                            .height * 0.5,
                        fit: BoxFit.contain,
                      ),
                    );
                  }

                  var userCreatedEvents = snapshot.data!.docs.where((document) {
                    final data = document.data() as Map<String, dynamic>;
                    return data['createdBy'] == currentUserUid;
                  }).toList();

                  if (userCreatedEvents.isEmpty) {
                    return Center(
                      child: Image.asset(
                        'assets/myeventEMPTY.jpeg',
                        width: MediaQuery
                            .of(context)
                            .size
                            .width * 1,
                        height: MediaQuery
                            .of(context)
                            .size
                            .height * 0.5,
                        fit: BoxFit.contain,
                      ),
                    );
                  }

                  return SingleChildScrollView(
                      child: AnimationLimiter(
                  child: Column(

                  children: AnimationConfiguration.toStaggeredList(
                  duration: const Duration(milliseconds: 375),
                  childAnimationBuilder: (widget) => SlideAnimation(
                  horizontalOffset: MediaQuery.of(context).size.width / 2,
                  child: FadeInAnimation(child: widget),
                  ),
                        children: userCreatedEvents.map((document) {
                          final data = document.data() as Map<String, dynamic>;
                          final dateTime = (data['dateTime'] as Timestamp)
                              .toDate();
                          final formattedDateTime =
                          DateFormat('yyyy-MM-dd – kk:mm').format(dateTime);

                          final int invitedUserLength = (data['isfavorite'] as List)
                              .length;
                          final int isGoingLength = (data['goingusers'] as List)
                              .length;
                          final bool isGoing =
                          (data['goingusers'] as List).contains(currentUserUid);

                          // final int inviteduserlength =  (data['isfavorite'] as List).length;
                          // final int iisGoinglength =  (data['goingusers'] as List).length;
                          //
                          //
                          return GestureDetector(
                            onLongPress: () async {
                              bool? confirmDelete = await showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    title: Text("Delete Event"),
                                    content: Text(
                                        "Are you sure you want to delete this event?"),
                                    actions: <Widget>[


                                      ourButton(
                                        title: 'Cancel',
                                        textColor: darkFontGrey,
                                        onpressed: () {
                                          Navigator.of(context).pop(false);
                                        },
                                      ),
                                      ourButton(
                                        title: 'Delete',
                                        textColor: darkFontGrey,
                                        onpressed: () async {
                                          await firestore.collection('events').doc(
                                              document.id).delete();
                                          Get.snackbar("Event Deleted",
                                              "Your event has been deleted successfully.");
                                          Navigator.of(context).pop(false);
                                        },
                                      ),

                                    ],
                                  );
                                },
                              );

                              if (confirmDelete == true) {
                                await firestore.collection('events').doc(
                                    document.id).delete();
                                Get.snackbar("Event Deleted",
                                    "Your event has been deleted successfully.");
                              }
                            },
                            child: Center(
                              child: categorywidget(
                                    () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          ViewSubjectScreen(
                                            title: data['title'] ?? 'No Title',
                                            interested: invitedUserLength
                                                .toString() ?? 'N/A',
                                            going: isGoingLength.toString() ??
                                                'N/A',
                                            description: data['description'] ??
                                                'No Description',
                                            dateTime: formattedDateTime,
                                            imageUrl: data['images'] ?? '',
                                            location: data['locationevent'] ??
                                                'No Location',
                                            organizer: data['organizer'] ??
                                                'Unknown',
                                            currentUserUid: currentUserUid,
                                            eventid: data['createdBy'] ??
                                                'No Description',
                                            lat: data['latitude'],
                                            long: data['longitude'],
                                            data: data,
                                          ),
                                    ),
                                  );
                                },
                                Icons.add,
                                data['title'] ?? 'No Title',
                                invitedUserLength.toString(),
                                isGoingLength.toString(),
                                data['description'] ?? 'No Description',
                                formattedDateTime,
                                Colors.black,
                                Colors.white,
                                data['images'][0] ?? '',
                                context,
                                data['locationevent'] ?? 'N/A',
                                    () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          NotifyAllUsersScreen(
                                            data: data,
                                          ),
                                    ),
                                  );
                                },
                                    () {},
                                Icons.notifications,
                                isGoing ? 'You are Going' : 'Going',
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ));
                },
              );
            }
            else {
              return Center(
                child: Image.asset('assets/slowconnections.jpeg'),
              );
            }
          })
      ),
    );
  }
}
